#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int main(void){
int b = open("b.txt", O_RDWR); 
printf("%d",b);
close(b);
}
